import streamlit as st
import tensorflow as tf
import numpy as np

# 1. Load the trained model
@st.cache_resource # This keeps the model in memory so it doesn't reload every time
def load_my_model():
    return tf.keras.models.load_model('text_classification_model.h5')

model = load_my_model()

# 2. Helper function to process input text
def preprocess_text(text):
    word_index = tf.keras.datasets.imdb.get_word_index()
    tokens = text.lower().split()
    # IMDb index starts at 3; 2 is for "unknown"
    sequence = [word_index.get(w, 2) + 3 for w in tokens]
    # Keep only words within the 10,000 vocab limit
    sequence = [i if i < 10000 else 2 for i in sequence]
    # Pad to match the training length (250)
    padded = tf.keras.preprocessing.sequence.pad_sequences([sequence], maxlen=250)
    return padded

# 3. Streamlit UI Design
st.title("🎬 Movie Review Sentiment Analyzer")
st.write("Type a review below to see if it's Positive or Negative!")

user_input = st.text_area("Enter Review:", placeholder="The cinematography was brilliant, but the plot was a bit slow...")

if st.button("Analyze Sentiment"):
    if user_input.strip() == "":
        st.warning("Please enter some text first.")
    else:
        # Process and Predict
        processed_input = preprocess_text(user_input)
        prediction = model.predict(processed_input)[0][0]
        
        # Display Result
        st.divider()
        if prediction > 0.5:
            st.success(f"### Result: Positive Review 😊")
            st.write(f"Confidence Score: {prediction:.2%}")
        else:
            st.error(f"### Result: Negative Review 😞")
            st.write(f"Confidence Score: {(1 - prediction):.2%}")